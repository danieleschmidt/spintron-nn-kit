"""
Simulation module for SpinTron-NN-Kit.

Provides behavioral and SPICE simulation capabilities for spintronic neural networks.
"""

from .behavioral import BehavioralSimulator
from .power_analysis import EnergyAnalyzer

__all__ = [
    "BehavioralSimulator",
    "EnergyAnalyzer",
]